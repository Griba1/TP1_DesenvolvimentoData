from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from datetime import datetime, timedelta

router = APIRouter()

class UserResponse(BaseModel):
    username: str
    message: str

class CreateUserRequest(BaseModel):
    username: str = Field(..., example="joao")
    age: int = Field(..., example=30)

class Item(BaseModel):
    name: str
    description: str = Field(..., example="Description the item")

class BirthdayRequest(BaseModel):
    name: str = Field(..., example="João")
    birthday: str = Field(..., example="2000-01-01")

fake_user_db = {"joao": "joao", "alice": "alice", "davi": "davi"}
fake_item_db = {
    1: {"name": "Item1", "description": "First item"},
    2: {"name": "Item2", "description": "Second item"}
}

class InvalidItemIDException(Exception):
    def __init__(self, item_id: int):
        self.item_id = item_id
        self.message = f"Invalid item_id: {item_id}. It must be a positive integer."
        super().__init__(self.message)

@router.get("/")
async def root():
    return {"message": "Hello, FastAPI!"}

@router.get("/status")
async def status():
    return {"status": "Server is running"}

@router.get("/user/{username}", response_model=UserResponse)
async def greet_user(username: str):
    if username not in fake_user_db:
        raise HTTPException(status_code=404, detail="User não encontrado")
    return UserResponse(username=username, message=f"Welcome, {username}!")

@router.post("/create-user")
async def create_user(user: CreateUserRequest):
    return {"username": user.username, "age": user.age}

@router.get("/item/{item_id}", response_model=Item)
async def get_item(item_id: int):
    if item_id <= 0:
        raise InvalidItemIDException(item_id)
    item = fake_item_db.get(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item não encontrado")
    return item

@router.delete("/item/{item_id}")
async def delete_item(item_id: int):
    if item_id <= 0:
        raise InvalidItemIDException(item_id)
    if item_id not in fake_item_db:
        raise HTTPException(status_code=404, detail="Item não encontrado")
    del fake_item_db[item_id]
    return {"message": f"Item com ID {item_id} deletado com sucesso"}

@router.post("/birthday")
async def calculate_birthday(birthday_request: BirthdayRequest):
    today = datetime.now()
    birthday = datetime.strptime(birthday_request.birthday, "%Y-%m-%d")
    
    next_birthday = birthday.replace(year=today.year)
    if next_birthday < today:
        next_birthday = next_birthday.replace(year=today.year + 1)

    days_until_birthday = (next_birthday - today).days

    return {
        "name": birthday_request.name,
        "message": f"{days_until_birthday} dias até seu proximo aniversario!"
    }
